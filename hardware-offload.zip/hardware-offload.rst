..  SPDX-License-Identifier: BSD-3-Clause
    Copyright(c) 2019 Nippon Telegraph and Telephone Corporation


.. _usecase_hardware_offload:

Hardware Offload
================

SPP provides hardware offload functions from SPP CLI.
This section shows you how to use hardware offload functions.

.. note::

    In this section, there are many NIC-vendar dependent information.
    We tested following use cases at Connect-X 5 by Mellanox only.
    Even if you cannot use these use cases on different NIC, we don't support.
    We would like to recomand that you ask DPDK ML, sometimes it's much
    than expected.

Hardware Classification
-----------------------

Some hardware(NIC) provides packet classification function based on
L2 mac address. This use case shows you how to use L2 classification.

.. _figure_spp_hardware_offload_classify:

.. figure:: ../images/setup/use_cases/spp_hardware_offload_classify.*
:width: 100%

Setup
~~~~~

Before using hardware packet classification, you must setup multi-queue
feature in Hardware(NIC). In ``bin/config.sh``, you can specify the
number of queues for rx and tx.

.. code-block:: sh

    PRI_PORT_QUEUE=(
     "0 rxq 10 txq 10"
     "1 rxq 16 txq 16"
    )

Above example includes the line ``1 rxq 10 txq 10``. First column ``0``
of this line specifies physical port number, ``rxq 10`` is for 10 rx-queues,
``txq 10`` is for 10 tx-queues.

After editing ``bin/config.sh``, you can launch SPP as following.

.. code-block:: console

    # launch with default URL http://127.0.0.1:7777
    $ bin/start.sh
    Start spp-ctl
    Start spp_primary
    Waiting for spp-ctl is ready ...
    Welcome to the SPP CLI. Type `help` or `?` to list commands.

    spp >
    /* T.B.D. : Change above message after tests.*/

Then, you can launch ``spp_vf`` like this:

.. code-block:: none

    spp > pri; launch vf 1 -l 1,2,4,6 -m 512 -- -n 3 -s 127.0.0.1:6666
    ...

Configuration
~~~~~~~~~~~~~
In this use case, two components ``fwd1`` and ``fwd2`` simply forward
the packet to multi-tx queues. You can start these components like this:

.. code-block:: none

    spp > vf 1; component start fwd1 1 forward
    spp > vf 1; component start fwd2 2 forward

Before configuring the flow of classifying packets, you can validate it like this:

.. code-block:: none

    spp > pri; flow validate phy:0 ingress group 1 pattern eth dst is 10:22:33:44:55:66 / end actions queue index 1 / end
    spp > pri; flow validate phy:0 ingress group 1 pattern eth dst is 10:22:33:44:55:67 / end actions queue index 2 / end

Then, you can configure flow like this:

.. code-block:: none

    spp > pri; flow create phy:0 ingress group 1 pattern eth dst is 10:22:33:44:55:66 / end actions queue index 1 / end
    spp > pri; flow create phy:0 ingress group 1 pattern eth dst is 10:22:33:44:55:67 / end actions queue index 2 / end

You can confirm created flow by ``flow list`` and ``flow status`` commands.
``flow list`` command provides the flow information of specified physical port.

.. code-block:: none

    spp > pri; flow list phy:0
    /* TBD: add reponse message here */

To get detailed information of each ``ID``(=0): 

.. code-block:: none

    spp > pri; flow status phy:0 0
    /* TBD: add reponse message here */


For each ``fwd1`` and ``fwd2``, configure the rx port like this:

.. code-block:: none

    spp > vf 1; port add phy:0 nq 1 rx fwd1
    spp > vf 1; port add phy:0 nq 2 rx fwd2

Then, you can configure tx ports like this:

.. code-block:: none

    spp > vf 1; port add phy:1 nq 1 tx fwd1
    spp > vf 1; port add phy:1 nq 2 tx fwd2

As confirming above configuration, you can use ping and tcpdump as described in
:numref:`spp_usecases_vf_cls_icmp:`.

Also, when you destroy the flow created above, commands will be:

.. code-block:: none

    spp > pri; destroy phy:0 0
    spp > pri; destroy phy:0 1

Or:

.. code-block:: none

    spp > pri; destroy phy:0 ALL

Manipulate VLAN tag
-------------------

Some hardware(NIC) provides VLAN tag manipulation function.
This use case shows you how to use this.

.. _figure_spp_hardware_offload_vlan:

.. figure:: ../images/setup/use_cases/spp_hardware_offload_vlan.*
   :width: 100%

After having done above use case, you can continue to followings.
In this use case, we are assuming incoming packets which includes
``vid=100`` to ``phy:0``, these vid will be removed(detagged) and
transferred to ``fwd1``. Tx packets from ``fwd1`` are sent to 
queue#0 on phy:1 with tagged by ``vid=100``. Packets which includes
``vid=200`` to ``phy:0`` are to be sent to ``fwd2`` with removing
the vid, 
Tx packets from ``fwd2`` are sent to queue#1 on phy:1 with tagged
by ``vid=200``.

For detagging flow creation:

.. code-block:: none

    spp > pri; flow create phy:0 ingress group 1 pattern eth dst is 10:22:33:44:55:66 / vlan vid is 100 / end actions queue index 1 / of_pop_vlan / end
    spp > pri; flow create phy:0 ingress group 1 pattern eth dst is 10:22:33:44:55:67 / vlan vid is 200 / end actions queue index 2 / of_pop_vlan / end
    /* TBD: above line exceed 80-charactor, how to work around?? */

For tagging flow creation:

.. code-block:: none

    spp > pri; flow create phy:1 egress group 1 pattern eth dst is 10:22:33:44:55:66 / end actions of_push_vlan ethertype 0x8100 / of_set_vlan_vid vlan_vid 100 / of_set_vlan_pcp vlan_pcp 3 / end
    spp > pri; flow create phy:1 egress group 0 pattern eth / end actions jump group 1 / end
    spp > pri; flow create phy:1 egress group 1 pattern eth dst is 10:22:33:44:55:67 / end actions of_push_vlan ethertype 0x8100 / of_set_vlan_vid vlan_vid 200 / of_set_vlan_pcp vlan_pcp 3 / end
    spp > pri; flow create phy:1 egress group 0 pattern eth / end actions jump group 1 / end
    /* TBD: above line exceed 80-charactor, how to work around?? */

If you want to send vlan-tagged packets, the NIC connected to ``phy:0``
will be configured by following:

.. code-block:: sh

    $ sudo vconfig add ens0 100
    $ sudo vconfig add ens0 200
    $ sudo ifconfig ens0.10 inet 192.168.241.31 netmask 255.255.255.0 up
    $ sudo ifconfig ens0.20 inet 192.168.242.31 netmask 255.255.255.0 up

Connecting with VMs
-------------------

This use case shows you how to configure hardware offload and VMs.

.. _figure_spp_hardware_offload_vm:

.. figure:: ../images/setup/use_cases/spp_hardware_offload_vm.*
   :width: 100%

First, we should clean up flows and delete ports:

.. code-block:: none

    spp > vf 1; port del phy:0 nq 0 rx fwd1
    spp > vf 1; port del phy:0 nq 1 rx fwd2
    spp > vf 1; port del phy:1 nq 0 tx fwd1
    spp > vf 1; port del phy:1 nq 1 tx fwd2
    spp > pri; destroy phy:0 ALL

Configure flows:

.. code-block:: none
    spp > pri; flow create phy:0 ingress group 1 pattern eth dst is 10:22:33:44:55:66 / vlan vid is 100 / end actions queue index 0 / of_pop_vlan / end 
    spp > pri; flow create phy:0 ingress group 1 pattern eth dst is 10:22:33:44:55:67 / vlan vid is 200 / end actions queue index 1 / of_pop_vlan / end 
    spp > pri; flow create phy:0 egress group 1 pattern eth dst is 10:22:33:44:55:66 / end actions of_push_vlan ethertype 0x8100 / of_set_vlan_vid vlan_vid 100 / of_set_vlan_pcp vlan_pcp 3 / end
    spp > pri; flow create phy:0 egress group 0 pattern eth / end actions jump group 1 / end
    spp > pri; flow create phy:0 egress group 1 pattern eth dst is 10:22:33:44:55:67 / end actions of_push_vlan ethertype 0x8100 / of_set_vlan_vid vlan_vid 200 / of_set_vlan_pcp vlan_pcp 3 / end
    spp > pri; flow create phy:0 egress group 0 pattern eth / end actions jump group 1 / end
    /* TBD: above line exceed 80-charactor, how to work around?? */

Start components(``fwd1`` and ``fwd2`` have already started):

.. code-block:: none
    spp > component start fwd3 4 forward
    spp > component start fwd4 6 forward    

Start and setup two VMs as described in :numref:`.. _spp_usecases_vf_ssh:`.
Add ports to forwarders:

.. code-block:: none
    spp > port add phy:0 nq 0 rx fwd1
    spp > port add phy:0 nq 1 rx fwd2
    spp > port add phy:0 nq 2 tx fwd3
    spp > port add phy:0 nq 3 tx fwd4
    spp > port add vhost:0 tx fwd1
    spp > port add vhost:0 tx fwd2
    spp > port add vhost:1 rx fwd3
    spp > port add vhost:1 rx fwd4

Then you can login to each VMs.
